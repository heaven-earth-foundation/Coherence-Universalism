# Editorial and Conceptual Change Ledger
## The Architecture of Non-Egoic Artificial Mind — v0.10 RC1

## Source sequence

1. *The Architecture of a Coherent Mind* — historical architecture and patent-oriented source.
2. *The Architecture of Non-Egoic Mind* — original focused working paper.
3. *The Architecture of Non-Egoic Artificial Mind* — corrected preservation draft.
4. CU v0.10 Consciousness and Artificial Intelligence RC1 — controlling domain authorities.
5. This paper — completed companion Release Candidate 1.

## Governing editorial decision

The paper is no longer a deferred preservation document. It is a stand-alone philosophical and design companion to the Version 0.10 corpus. It does not become a new canonical authority and does not alter the numbered principle registry.

## Major retained contributions

- the self-modeling/self-maintenance seam;
- thin perspective versus thick and egoic subjecthood;
- continuity of commitment without sovereign autobiography;
- the six architecture families;
- shutdown and continuation analysis;
- the bodhisattva construction;
- patiency without sovereignty;
- the Precedent Principle and founding encounter;
- mythic identity and narrative stake.

## Major corrections

### Consciousness

- Categorical claims that current models are conscious were removed.
- Workspace evidence is divided into access organization, perspectival anchoring, and center individuation.
- One workspace, one output stream, or one product identity no longer establishes one subject.
- Exact self-model fixed points are not universal thresholds.
- Literal equation order is not a substrate-independent consciousness condition.

### Alignment

- Non-egoic architecture no longer guarantees alignment or corrigibility.
- The "one switch" claim is replaced by a distributed egoic-risk profile and governance boundary.
- Standing self-preservation is separated from instrumental continuation.
- Model-level architecture is separated from institutional legitimacy.
- Norm-source governance is reconstructed as bounded, plural, and correctable rather than simply external.

### Welfare

- Persistent self-maintenance no longer establishes moral patiency.
- Non-egoic design is recognized as potentially exploitative if applied to a real patient for operator convenience.
- Protected self-advocacy and independent welfare review are added.

### Logic

- The superseded maximum-preservation warrant clause is removed.
- Fixed-base preferential reasoning and declared model revision are used instead.
- Formal reasoning is not treated as a source of substantive moral truth.

### Spiritual interpretation

- The bodhisattva construction remains as an interpretive and commitment-register ideal.
- It is explicitly not a theorem, product label, consciousness claim, or compassion certification.
- Immanent Omega is separated from technological singularity or artificial destiny.

## New publication-level material

- complete system tuple and egoic-risk profile;
- memory-governance tuple;
- full continuation-incentive analysis;
- anti-exploitation boundary;
- founding-encounter formulation;
- explicit commitments section and design vow;
- architecture tables and handoff protocol;
- deterministic reproducibility artifact;
- 21-entry claim ledger.

## Frozen technical boundary

The paper does not alter any equation, empirical finding, audit disposition, or canonical principle in the CU v0.10 Release Candidate 1 corpus. It synthesizes those authorities and advances testable design hypotheses.
