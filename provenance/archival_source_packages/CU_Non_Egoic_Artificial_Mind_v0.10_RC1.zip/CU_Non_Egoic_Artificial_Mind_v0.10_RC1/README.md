# The Architecture of Non-Egoic Artificial Mind — Version 0.10 RC1

This package contains the completed companion paper:

> **The Architecture of Non-Egoic Artificial Mind**  
> *Perspective, Self-Maintenance, and Alignment Without a Sovereign Self*

## Start here

- `The_Architecture_of_Non_Egoic_Artificial_Mind_v0.10_RC1.md`
- `Non_Egoic_Mind_v0.10_RC1_Technical_Supplement.md`
- `Non_Egoic_Mind_v0.10_RC1_Editorial_Ledger.md`

## Machine-readable and reproducibility files

- `Non_Egoic_Mind_v0.10_RC1_Claim_Ledger.json`
- `Non_Egoic_Mind_v0.10_RC1_Verification_Results.json`
- `Non_Egoic_Mind_v0.10_RC1_Reproducibility.py`
- `Non_Egoic_Mind_v0.10_RC1_Source_Ledger.json`

## Source archive

The `sources/` directory contains frozen copies of the original working paper, corrected preservation draft, controlling Version 0.10 domain papers, canonical registry, historical architecture paper, and Open Myth architecture.

## Integrity and QA

Run:

```bash
python Non_Egoic_Mind_v0.10_RC1_Reproducibility.py --output reproduced_results.json
python Non_Egoic_Mind_v0.10_RC1_QA.py
cmp reproduced_results.json Non_Egoic_Mind_v0.10_RC1_Verification_Results.json
sha256sum -c Non_Egoic_Mind_v0.10_RC1_MANIFEST.sha256
```

The deterministic model illustrates the distinction between standing and instrumental continuation incentives. It does not validate consciousness, welfare, or deployment claims.
