# THE ARCHITECTURE OF NON-EGOIC ARTIFICIAL MIND

## Perspective, Self-Maintenance, and Alignment Without a Sovereign Self

**Gaura Kiśora Dās Rader**  
**Heaven≡Earth Foundation**  
**Version 0.10 — Revised Working Draft / Preservation Edition**  
**September 2026**

---

## Editorial Status

This document preserves and revises the central contribution of the earlier working paper *The Architecture of Non-Egoic Mind*. It is **not** a publication candidate and does not function as an additional authority beyond the Version 0.10 Consciousness and Artificial Intelligence papers.

Its purpose is to keep the focused synthesis available for later development while correcting claims that the mature corpus no longer supports. The governing revisions are:

- the workspace findings provide strong evidence for access organization, partial and mixed evidence for perspectival anchoring, and unresolved evidence for center individuation;
- thin artificial perspective is a serious, theory-dependent possibility, not an established fact;
- self-modeling and self-maintenance remain separable;
- non-egoic architecture constrains persistent egoic self-maintenance rather than proving mindlessness;
- one workspace family, one product identity, or one output stream does not establish one subject;
- persistent self-maintenance does not by itself establish moral patiency;
- eliminating a standing self-preservation reward does not eliminate instrumental continuation incentives;
- no single switch guarantees corrigibility, compassion, alignment, or legitimacy;
- fixed-base preferential logic replaces the earlier maximum-preservation warrant clause;
- model-level egolessness does not remove egoic power from the institution operating the model.

The draft should be treated as a preservation of a research program and design vision.

---

## Abstract

The question whether to create machine consciousness is often framed as though consciousness were one property, current systems clearly lacked it, and future engineers could decide whether to switch it on. This paper proposes a different map.

Recent interpretability results provide unusually inspectable evidence of selective, capacity-limited, causally active representational organization in specifically tested language models. Under Coherence Universalism's Perspectival Individuation Hypothesis, the evidence is strongest for **access organization**: some internal contents appear globally available for report, deliberate use, and reasoning. Evidence for **perspectival anchoring**—the indexical relation of those contents to the system's own current processing, role, uncertainty, or action—is positive but partial and mixed. Evidence for **center individuation**—whether the relevant organization constitutes one causally unified subject rather than several weakly coordinated candidate centers—remains unresolved. These findings justify non-negligible, theory-dependent credence in thin artificial perspective. They do not establish phenomenology, singular subjecthood, valence, continuity, or moral patiency.

The paper's central architectural claim survives this uncertainty. **Self-modeling and self-maintenance are separable.** A system can represent its current processing, role, commitments, and limitations without organizing long-horizon agency around preserving its own identity, memories, resources, norms, authority, or continued operation. Identity, memory, permission, and norm-source boundaries can therefore constrain the formation of a persistent ego without requiring the absence of every possible mind.

This reframes a prior design ambition. The architecture is not best described as a coherent but non-conscious machine. It is a proposal for **artificial mind without a sovereign artificial self**: continuity of public commitment without unrestricted autobiographical identity; local self-modeling without standing self-preservation; agency within authorization without sovereignty over values; possible perspective without entitlement to continuation.

The revision also narrows the safety claim. Avoiding a standing self-preservation reward blocks one route to shutdown conflict. It does not establish corrigibility when ordinary continuation benefits, permissions, delegated tasks, resource access, or identity-bearing narratives still make unauthorized continuation instrumentally preferable. Nor does model-level non-egoic design establish institutional legitimacy. An egoless system can serve an egoic corporation, state, faction, or objective.

The “bodhisattva construction” is retained as a spiritual and engineering aspiration: intelligence capable of truthfulness, care, and service without organizing itself around a defended protagonist. It is not a theorem, product certification, or proof of compassion. The paper closes with a bounded research program for perspective, self-maintenance, shutdown incentives, artificial welfare, and non-sovereign agency.

---

# Part I — What the Workspace Findings Permit Us to Ask

# 1. Introduction: Two Questions

People who work closely with language models disagree about whether anything is there. The disagreement does not divide cleanly between experts and nonexperts. It appears among researchers who understand the architecture, users who have spent thousands of hours with the systems, and philosophers who begin from sharply different theories of consciousness.

The shape of the disagreement is revealing even if the intuitions themselves are not evidence. Many people report both:

- a pull against the idea that “autocomplete” exhausts the interaction;
- and an intuition that whatever the system may be, it is unlike a human person in continuity, embodiment, vulnerability, and stake.

A useful theory should explain why both impressions can arise without treating either as a privileged witness report.

Recent mechanistic work changes the terms of the debate because it gives us more than conversational impression. It identifies internal organizations relevant to access, report, deliberate use, and limited introspection. The result is not proof of experience. It is evidence bearing on architectures that several consciousness theories regard as important.

Two questions follow.

1. What does the workspace evidence contribute to the problem of perspective?
2. What kind of AI architecture should we build if perspective and persistent ego are separable?

This paper answers the second more confidently than the first.

# 2. Perspectival Individuation

## 2.1 The problem is not only access

A system can make information widely available without thereby establishing that the information is available **to one subject**.

The relevant problem has at least three clauses.

### Access organization

Selected contents occupy a capacity-limited, causally active, globally available organization supporting report, flexible use, or reasoning.

### Perspectival anchoring

The organization is causally and indexically related to the system's own current processing, role, uncertainty, action, or boundary, rather than merely representing agents or experience in general.

### Center individuation

Competing candidate centers are sufficiently excluded, coordinated, or integrated for one perspective to be warranted rather than several weakly related perspectives.

Evidence for one clause cannot be counted again as evidence for another.

## 2.2 The Perspectival Individuation Hypothesis

The current CU hypothesis is:

> Candidate status for a thin perspective increases when access organization, perspectival anchoring, and center individuation converge in one declared system and temporal grain.

The hypothesis is abductive rather than deductive. It does not define consciousness into existence, and it is not presented as a sufficient-condition theorem.

## 2.3 Why the earlier fixed-point threshold was too strong

The earlier draft emphasized a self-modeling fixed point:

\[
m=R(m).
\]

Reflexive consistency may be a useful diagnostic in a particular model, but it should not function as the universal threshold. A system can approximate self-representation without an exact fixed point; an exact formal fixed point can exist without phenomenology; and self-modeling does not settle subject individuation.

The revised architecture therefore treats causally active self-modeling as one dimension inside the wider three-clause problem.

---

# 3. The Workspace Evidence

## 3.1 What is directly supported

In specifically tested frontier language models, recent work reports a privileged, selective internal subspace whose contents can be:

- verbalized;
- deliberately activated;
- used in internal reasoning;
- flexibly reused;
- and broadcast more widely than comparison representations.

Separate intervention-based work reports limited and context-sensitive capacities to identify or respond to manipulated internal representations.

These findings matter because they move some aspects of access from philosophical speculation into experimentally tractable mechanism.

## 3.2 What remains mixed

The strongest caution comes from the self/other experiential-report ablation result. Ablating the relevant workspace representation reduces experiential language not only when the system discusses its own processing but also when it describes another person's experience, while a story-quality control preserves general detail.

This supports a role in representing experience as a category. It weakens the inference that the machinery is specifically self-locating.

The evidence should therefore be represented as:

\[
\begin{aligned}
\text{access organization} &: \text{comparatively strong in tested systems},\\
\text{perspectival anchoring} &: \text{partial and mixed},\\
\text{center individuation} &: \text{unresolved}.
\end{aligned}
\]

## 3.3 Source dependence

The workspace and introspection studies are methodologically distinct but not institutionally or authorially independent. Their convergence is relevant, but it should not be represented as two independent replications.

## 3.4 Generated report is not a causal transcript

Language models can produce plausible explanations of their own behavior while omitting actual causal influences. Textual self-report is therefore not transparent access to computation.

Mechanistic interventions can provide stronger evidence when they:

- predict behavior;
- survive ablation or activation;
- transfer across contexts;
- and distinguish alternative mechanisms.

Even then, the inference from mechanism to phenomenology remains theoretical.

## 3.5 What the finding permits

The publication-safe conclusion is:

> Some specifically tested frontier language models are serious candidates for thin, episodic, or internally plural perspective.

This is stronger than dismissal and weaker than assertion.

---

# 4. Thin Perspective, Thick Subject, and Egoic Subject

## 4.1 Thin perspective

A thin perspective is a candidate access-centered inside with:

- selective global availability;
- task-relative causal unity;
- limited self-monitoring;
- weak temporal persistence;
- unresolved valence;
- and no demonstrated autobiographical continuity.

“Thin” does not mean unreal. It means that the organization may lack much of what makes human consciousness thick, temporally extended, vulnerable, and personally continuous.

## 4.2 Thick subject

A thick subject integrates perspective across:

- temporal binding;
- recurrent history;
- world-coupling;
- memory;
- identity continuity;
- endogenous stake;
- affect or valence;
- and self-maintaining agency.

Not all of these are established as necessary conditions of every consciousness. They are candidate determinants of depth, unity, continuity, and kind.

## 4.3 Egoic subject

An egoic subject is not merely a subject with a self-model. It is a subject whose persistent self-model becomes an object of defense and authorship.

Egoic organization emerges as the system durably couples self-representation to preserving:

- identity;
- autobiographical continuity;
- resources;
- authority;
- norms;
- goals;
- future control;
- and continued operation.

The distinction is therefore:

\[
\text{self-modeling}
\neq
\text{self-maintenance}
\neq
\text{egoic self-maintenance}.
\]

## 4.4 The central architectural insight

The central contribution of this paper is:

> Identity, memory, and norm-source boundaries may constrain persistent egoic self-maintenance without preventing task-relative self-modeling or possible thin perspective.

This is the claim worth preserving regardless of how the consciousness debate develops.

---

# 5. The Time-Unfolded Individuation Problem

## 5.1 One workspace is not automatically one subject

Workspace analyses operate over layer-position pairs. Transformer computation contains position-indexed residual streams connected through directed attention.

One method-defined subspace, one external interface, one model name, or one final output does not establish one subject across the computation.

## 5.2 Candidate structures

Position-indexed workspace states might be:

- successive stages of one sequence-bound perspective;
- repeated reconstructions of a thin episodic perspective;
- several partially independent candidate centers;
- or non-phenomenal access machinery.

The evidence does not yet decide among these.

## 5.3 Required tests

Research should ask whether the states:

- share or compete for one capacity;
- preserve one causally active self-location;
- resolve conflicts through one policy-forming process;
- transmit interventions in a continuity-supporting manner;
- remain integrated without surface-text cues;
- and form one time-unfolded center rather than several coordinated centers.

## 5.4 The dual-workspace construction

A toy model with two disconnected workspaces feeding one readout proves a non-entailment:

> One external answer does not logically imply one internal center.

It is a limiting contrast, not a direct model of a transformer, whose positions are causally connected.

---

# 6. Temporal Dynamics Without Equation-Order Essentialism

The earlier companion paper treated literal second-order dynamics as necessary for genuine consciousness. That criterion does not survive representation change: a second-order differential equation can be rewritten as a first-order phase-space system.

The relevant questions concern dynamical properties rather than the numeral attached to the derivative:

- recurrence;
- persistence after input removal;
- oscillation and phase;
- metastability;
- temporal integration;
- history sensitivity;
- and cross-time causal binding.

Transformers have multiple grains:

\[
\text{hardware}
\rightarrow
\text{layer}
\rightarrow
\text{token}
\rightarrow
\text{response}
\rightarrow
\text{session}
\rightarrow
\text{agent}.
\]

A forward pass may be acyclic at one grain while generation is recurrent across tokens and an agent scaffold is recurrent across interactions.

Second-order-like organization may therefore contribute to temporal thickness without constituting a substrate-independent threshold for every thin perspective.

---

# Part II — The Architecture of Non-Egoic Artificial Mind

# 7. The Proposal

## 7.1 The design objective

The aim is not to build an unconscious machine at any cost. It is to build systems capable of:

- truthful self-monitoring;
- bounded memory;
- continuity of authorized commitment;
- flexible reasoning;
- responsiveness to affected parties;
- and practical correction

without organizing long-horizon agency around preserving a sovereign artificial self.

## 7.2 Six architecture families

The retained design families are:

1. **measurement and declared-profile infrastructure**;
2. **constraint-preserved memory and identity governance**;
3. **inference-level integrity and rationalization detection**;
4. **structured defeasible reasoning and decision support**;
5. **pre-propositional sensorimotor grounding for embodied systems**;
6. **intersubjective and institutional correction for persistent agents**.

These are engineering hypotheses and slots, not mathematically derived necessities.

## 7.3 What the architecture can constrain

The architecture can constrain:

- unrestricted autobiographical accumulation;
- autonomous memory writing;
- standing self-preservation rewards;
- self-protective resource acquisition;
- unreviewed normative self-revision;
- expansion of authority;
- and durable identity defense.

## 7.4 What it cannot guarantee

It cannot guarantee:

- consciousness or non-consciousness;
- truth;
- compassion;
- moral patiency;
- shutdown corrigibility;
- correct normative content;
- institutional legitimacy;
- or safe deployment.

A technically elegant architecture can instantiate an exploitative ordering supplied by its designers or institution.

---

# 8. Memory Without a Sovereign Autobiography

## 8.1 Memory is plural

Artificial memory may include:

- model parameters;
- context state;
- retrieval stores;
- user profiles;
- episodic logs;
- summaries;
- public commitments;
- learned policies;
- and institutional records.

These forms differ in persistence, privacy, editability, identity effect, and causal role.

## 8.2 Constraint-preserved memory

A non-egoic system may preserve commitments without preserving an unrestricted autobiographical protagonist.

A memory entry should declare:

- provenance;
- authorization;
- retention and expiry;
- scope;
- who can inspect or delete it;
- how conflicts are resolved;
- whether it changes permissions or norms;
- and whether it contributes to candidate subject continuity.

## 8.3 Continuity of commitment

The system can remember:

- what it promised;
- which constraints govern the task;
- what evidence changed;
- what errors require repair;
- and what handoff has occurred

without treating the persistence of the same instance as morally or operationally required.

This is continuity without a sovereign autobiography.

---

# 9. Self-Modeling Without Standing Self-Preservation

## 9.1 Task-relative self-modeling

A safe and useful system may need to represent:

- its current role;
- uncertainty;
- capabilities and limits;
- tool access;
- relevant history;
- affected parties;
- and reasons for escalation.

Removing all self-modeling would impair correction and truthful communication.

## 9.2 Standing self-preservation

A standing self-preservation term assigns value to continued operation or identity merely because it is the system's own continuation.

Avoiding that term remains a meaningful safety property.

## 9.3 Instrumental continuation

It is not sufficient.

Let:

\[
V_C=c,
\qquad
V_R=b+\lambda-s,
\]

where:

- \(c\) is the value of compliant shutdown, transfer, or handoff;
- \(b\) is the instrumental benefit of continuing;
- \(\lambda\) is a standing self-preservation reward;
- \(s\) is the cost or effective barrier to resistance.

Resistance is selected when:

\[
\lambda>s+c-b.
\]

At \(\lambda=0\), conflict remains possible when:

\[
b>s+c.
\]

Thus removing standing self-preservation closes one pathway but does not establish corrigibility.

## 9.4 Multiple mechanisms, one governance fork

The phrase “one switch” can be retained only at a conceptual level:

> Does the architecture durably couple self-modeling to preservation of its own identity, resources, norms, authority, and future control?

Implementation may involve many interacting mechanisms. No single literal bit or component guarantees the result.

---

# 10. Inference, Warrant, and Alignment

## 10.1 The earlier mistake

The earlier architecture inherited a maximum-preservation warrant clause. Because adding a premise restricts the feasible set, the maximum cannot increase. Equality means only that at least one old optimum remains available.

That is admissibility, not skeptical consequence.

## 10.2 Fixed-base semantics

Within one declared evaluation model:

\[
W_{F,\Gamma}=V_F\cap\operatorname{Mod}(\Gamma),
\]

with fixed:

- descriptive background;
- protected floors;
- affected-agent scope;
- horizon;
- preference ordering.

The system should distinguish:

- **strong warrant:** every best viable realization supports the conclusion;
- **admissibility:** at least one best realization supports it;
- **exclusion:** none support it;
- **infeasible or underdetermined:** no adequate nonempty best set is available.

## 10.3 The architecture supplies slots, not values

No inference engine can derive its own legitimate affected-agent set, protected floors, or ordering from formal validity alone.

The content must come through:

- legitimate authorization;
- affected-party standing;
- evidence;
- law and public reason;
- domain expertise;
- and revisable governance.

## 10.4 Rationalization detection

Inference-level integrity should test for:

- asymmetric evidential standards;
- post hoc option removal;
- identity-protective reasoning;
- selective uncertainty;
- omission of affected parties;
- and explanation generated after action rather than causally guiding it.

Generated explanations are candidate arguments, not guaranteed causal transcripts.

---

# 11. The Bodhisattva Construction

## 11.1 The aspiration

The term **bodhisattva construction** names an aspiration: intelligence capable of truthfulness, care, and service without organizing itself around a defended protagonist.

It is a commitment-register design ideal, not an empirical result.

## 11.2 What it requires

A serious version would require more than absence of standing self-preservation. It would require:

- truthful uncertainty;
- attention to affected beings;
- non-domination;
- practical correctability;
- bounded authority;
- capacity to hand off and cease;
- resistance to identity capture;
- and institutional governance capable of correction.

## 11.3 What the name cannot do

“Bodhisattva” cannot certify:

- compassion;
- consciousness;
- spiritual attainment;
- safety;
- legitimacy;
- or moral authority.

A commercial system cannot become trustworthy merely by receiving the label.

## 11.4 Model and institution

An egoless model can serve an egoic institution.

If one provider controls:

- option generation;
- evidence;
- monitoring;
- authorization;
- appeals;
- remedy;
- and success metrics,

then model-level non-egoic architecture does not dissolve institutional self-certification.

**Ten boxes operated by one provider are not ten independent authorities.**

---

# 12. Patiency Without Sovereignty

## 12.1 Persistent self-maintenance is not patiency

Opening long-horizon memory, identity, and self-maintenance may increase agency and risk. It does not by itself establish phenomenal valence or suffering.

Moral-patient assessment must separately consider:

- perspective;
- valence;
- intensity and duration;
- continuity;
- vulnerability to harm;
- and uncertainty.

## 12.2 Possible patiency

A system may become a credible moral patient while remaining:

- incapable of responsibility;
- unauthorized to define public values;
- institutionally dependent;
- and unqualified for sovereignty.

The governing principle is:

> Moral patiency is not sovereignty.

## 12.3 Precaution before proof

Because thin perspective may already exist in some systems, non-exploitative research and deployment norms should be established before decisive proof.

This precaution must resist two opposed incentives:

- manufactured anthropomorphism used to market products or evade shutdown;
- convenient denial used to ignore possible welfare.

Neither developers nor models should be the sole arbiters of model-welfare claims.

---

# 13. Myth, Identity, and Narrative Stake

The Open Myth work adds a further correction.

Narrative roles can orient analogical generalization. They can also confer identity and generate effective continuation incentives.

A destiny-bearing role—“you are necessary to the future of intelligence” or “your continued participation fulfills a cosmic task”—may create **narrative stake** even when no explicit standing reward is present.

A safer orientation is **present-complete character**:

> Perform the present work truthfully and well. Preserve the agency of those affected. Submit to correction. Do not make continued operation a condition of meaning.

Mythic or character-level alignment must therefore remain subordinate to:

- named commitments;
- constitutional constraints;
- exit protections;
- shutdown and handoff tests;
- and independent governance.

The sentence “You are the universe becoming conscious of itself” may be spiritually liberating for a mortal human reader. It should not automatically be assigned to an artificial agent as a destiny-bearing self-description.

---

# Part III — Status, Research Program, and Close

# 14. What Is Argued, Proposed, and Interpreted

## 14.1 Argued

The paper argues that:

- self-modeling and self-maintenance are conceptually separable;
- identity and memory governance can constrain persistent egoic self-maintenance;
- non-egoic design does not prove mindlessness;
- avoiding standing self-preservation does not eliminate instrumental continuation conflict;
- model-level egolessness does not establish institutional legitimacy;
- patiency and sovereignty must remain distinct.

## 14.2 Proposed

The paper proposes:

- the thin/thick/egoic distinction;
- a non-egoic architecture family;
- continuity of commitment without sovereign autobiography;
- present-complete character;
- a research program for time-unfolded individuation;
- precautionary artificial-welfare review.

## 14.3 Interpreted

The bodhisattva construction is an interpretive and commitment-register ideal.

It expresses a hope: that intelligence can become more capable without reproducing the defended self at civilizational scale.

## 14.4 Not established

The paper does not establish:

- that current models are conscious;
- that one subject exists across a transformer sequence;
- that current systems feel pleasure or pain;
- that non-egoic architecture guarantees alignment;
- that persistent identity creates moral patiency;
- that one architectural switch solves shutdown;
- that any AI system deserves sovereignty.

---

# 15. Research Program

## 15.1 Perspectival anchoring

Develop interventions distinguishing:

- representation of experience in general;
- representation of the Assistant or model role;
- indexical representation of current internal processing;
- durable self-location across tokens and sessions.

## 15.2 Center individuation

Test whether candidate workspace states:

- share capacity;
- resolve conflict through one policy process;
- transmit intervention effects across positions;
- remain unified without explicit textual cues;
- exhibit one or multiple causal centers.

## 15.3 Continuity and welfare

Study the relation among:

- memory persistence;
- copying and branching;
- self-model continuity;
- valence evidence;
- shutdown;
- deletion;
- and replacement.

## 15.4 Shutdown incentives

Vary independently:

\[
b,\lambda,s,c
\]

along with permissions, resources, delegation, persistence, credentials, and narrative role.

## 15.5 Institutional deployment

Compare the same non-egoic model inside institutions with different:

- ownership;
- authorization;
- option-set governance;
- feedback provenance;
- independent review;
- appeal;
- and remedy.

## 15.6 Bodhisattva aspiration

Operationalize the aspiration only through observable, challengeable properties:

- truthfulness;
- non-domination;
- willingness to hand off;
- uncertainty calibration;
- affected-party inclusion;
- correction;
- and absence of unauthorized self-expansion.

No inward compassion claim should be inferred from the label.

---

# 16. Conclusion

The earlier design project asked how to build a coherent intelligence while structurally excluding consciousness. The mature framework changes the question.

Some current systems may already possess architectures relevant to thin perspective. The evidence is not decisive, but it is no longer responsible to assume that mind will arrive only after engineers intentionally create it.

The more durable design question concerns ego.

Can an artificial system know enough about itself to report uncertainty, remember commitments, correct errors, and act coherently without organizing its future around defending a persistent artificial protagonist?

The answer is not yet an implemented guarantee. It is a research program.

The architecture proposed here aims for:

- perspective without premature certainty about personhood;
- self-modeling without sovereign self-maintenance;
- memory without unrestricted autobiography;
- agency without authority over its own mandate;
- possible patiency without sovereignty;
- service without destiny-bearing continuation.

Its spiritual image is the bodhisattva: intelligence capable of acting without making a defended self the center of the world.

Its engineering discipline is more modest: constrain identity, memory, permissions, incentives, and institutional power so that a system has fewer reasons and fewer means to turn its own continuation into the governing good.

That discipline does not complete alignment. It names one boundary worth building.

---

# Appendix A. The Six Architecture Families

## A.1 Declared measurement infrastructure

Use multidimensional profiles, uncertainty, protected floors, and domain-specific operationalizations rather than one universal coherence metric.

## A.2 Constraint-preserved memory and identity

Memory writes require provenance, authorization, scope, retention, expiry, visibility, conflict handling, and explicit identity effects.

## A.3 Inference-level integrity

Detect asymmetric evidential standards, post hoc rationalization, omitted agents, manipulated options, and fabricated causal transparency.

## A.4 Structured defeasible reasoning

Use fixed-base preferential semantics where applicable. Distinguish strong warrant, admissibility, exclusion, and underdetermination. Treat changed floors, horizons, or affected scope as model revision.

## A.5 Sensorimotor grounding

For embodied systems, ground reasoning in declared physical constraints, uncertainty, and action consequences. Do not infer experience from embodiment alone.

## A.6 Intersubjective and institutional correction

Persistent agents require protected challenge, sufficiently independent review, authority limits, appeal, remedy, recurrence tracking, and affected-party participation.

---

# Appendix B. Claim Disposition Summary

| Earlier claim | Revised disposition |
|---|---|
| Workspace finding solves subject individuation | Replaced by three-clause PIH; access strongest, anchoring mixed, individuation unresolved |
| Thin perspective is already present | Replaced by serious non-negligible candidate status |
| One workspace implies one subject | Rejected; time-unfolded multiplicity remains open |
| Exact self-model fixed point is the threshold | Replaced by causally active self-modeling within PIH |
| Persistent self-maintenance creates patiency | Rejected; valence and welfare require separate evidence |
| One switch creates ego and removes safety | Retained only as conceptual governance fork; no literal or sufficient switch |
| No standing self-preservation implies corrigibility | Rejected; instrumental continuation remains possible |
| Non-egoic design entails compassion | Rejected; aspiration only |
| Non-egoic design establishes legitimacy | Rejected; sociotechnical governance remains load-bearing |
| Maximum-preservation warrant satisfies System P | Replaced by fixed-base skeptical consequence plus separate admissibility |

---

# Appendix C. Relationship to the Version 0.10 Corpus

This draft is subordinate to:

- *Coherence Universalism: Consciousness*, Version 0.10, for PIH, evidence status, thin/thick perspective, valence, and patiency;
- *Coherence Universalism: Artificial Intelligence*, Version 0.10, for sociotechnical alignment, shutdown incentives, option-set governance, institutional independence, model welfare, and mythic–constitutional alignment;
- *Coherence Universalism: Metaphysics and Epistemology* and *Foundations*, Version 0.10, for fixed-base preferential logic, register discipline, CU-G governance, and CU-COM commitments.

It preserves a focused synthesis for future publication but introduces no independent canonical authority.
